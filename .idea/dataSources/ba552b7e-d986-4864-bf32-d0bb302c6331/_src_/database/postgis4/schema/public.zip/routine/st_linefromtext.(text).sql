CREATE FUNCTION st_linefromtext (text) RETURNS geometry
	LANGUAGE sql
AS $$
	SELECT CASE WHEN geometrytype(public.ST_GeomFromText($1)) = 'LINESTRING'
	THEN public.ST_GeomFromText($1)
	ELSE NULL END
	
$$

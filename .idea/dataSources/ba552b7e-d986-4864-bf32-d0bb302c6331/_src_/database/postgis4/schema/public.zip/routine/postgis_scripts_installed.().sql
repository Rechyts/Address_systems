CREATE FUNCTION postgis_scripts_installed () RETURNS text
	LANGUAGE sql
AS $$
 SELECT '2.3.0'::text || ' r' || 15146::text AS version 
$$

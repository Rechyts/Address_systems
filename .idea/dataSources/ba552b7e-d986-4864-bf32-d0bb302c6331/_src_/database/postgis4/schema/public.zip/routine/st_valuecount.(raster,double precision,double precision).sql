CREATE FUNCTION st_valuecount (rast raster, searchvalue double precision, roundto double precision DEFAULT 0) RETURNS integer
	LANGUAGE sql
AS $$
 SELECT ( public._ST_valuecount($1, 1, TRUE, ARRAY[$2]::double precision[], $3)).count 
$$

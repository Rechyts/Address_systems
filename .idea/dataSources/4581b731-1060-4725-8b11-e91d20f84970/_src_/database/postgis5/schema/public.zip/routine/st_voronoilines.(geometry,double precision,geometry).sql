CREATE FUNCTION st_voronoilines (g1 geometry, tolerance double precision DEFAULT 0.0, extend_to geometry DEFAULT NULL::geometry) RETURNS geometry
	LANGUAGE sql
AS $$
 SELECT public._ST_Voronoi(g1, extend_to, tolerance, false) 
$$

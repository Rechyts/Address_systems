CREATE FUNCTION st_multipolygonfromtext (text, integer) RETURNS geometry
	LANGUAGE sql
AS $$
SELECT public.ST_MPolyFromText($1, $2)
$$

CREATE FUNCTION st_approxquantile (rast raster, sample_percent double precision, quantiles double precision[] DEFAULT NULL::double precision[], OUT quantile double precision, OUT value double precision) RETURNS SETOF record
	LANGUAGE sql
AS $$
 SELECT public._ST_quantile($1, 1, TRUE, $2, $3) 
$$

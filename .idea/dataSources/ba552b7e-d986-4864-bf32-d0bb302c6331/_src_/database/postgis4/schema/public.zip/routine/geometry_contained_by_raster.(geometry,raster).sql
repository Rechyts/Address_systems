CREATE FUNCTION geometry_contained_by_raster (geometry, raster) RETURNS boolean
	LANGUAGE sql
AS $$
select $1 @ $2::geometry
$$

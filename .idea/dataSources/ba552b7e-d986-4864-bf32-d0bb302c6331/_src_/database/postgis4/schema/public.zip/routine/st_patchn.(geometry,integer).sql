CREATE FUNCTION st_patchn (geometry, integer) RETURNS geometry
	LANGUAGE sql
AS $$
	SELECT CASE WHEN public.ST_GeometryType($1) = 'ST_PolyhedralSurface'
	THEN public.ST_GeometryN($1, $2)
	ELSE NULL END
	
$$

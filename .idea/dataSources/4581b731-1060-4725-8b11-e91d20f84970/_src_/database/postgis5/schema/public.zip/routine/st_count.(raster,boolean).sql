CREATE FUNCTION st_count (rast raster, exclude_nodata_value boolean) RETURNS bigint
	LANGUAGE sql
AS $$
 SELECT public._ST_count($1, 1, $2, 1) 
$$

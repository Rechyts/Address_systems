CREATE FUNCTION st_mpointfromtext (text) RETURNS geometry
	LANGUAGE sql
AS $$
	SELECT CASE WHEN public.geometrytype(public.ST_GeomFromText($1)) = 'MULTIPOINT'
	THEN public.ST_GeomFromText($1)
	ELSE NULL END
	
$$

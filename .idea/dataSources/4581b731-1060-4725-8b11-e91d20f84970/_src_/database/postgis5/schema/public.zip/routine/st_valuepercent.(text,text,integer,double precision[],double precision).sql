CREATE FUNCTION st_valuepercent (rastertable text, rastercolumn text, nband integer, searchvalues double precision[], roundto double precision DEFAULT 0, OUT value double precision, OUT percent double precision) RETURNS SETOF record
	LANGUAGE sql
AS $$
 SELECT value, percent FROM public._ST_valuecount($1, $2, $3, TRUE, $4, $5) 
$$

CREATE FUNCTION st_multilinestringfromtext (text) RETURNS geometry
	LANGUAGE sql
AS $$
SELECT public.ST_MLineFromText($1)
$$

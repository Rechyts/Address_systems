CREATE FUNCTION _st_bestsrid (geography) RETURNS integer
	LANGUAGE sql
AS $$
SELECT public._ST_BestSRID($1,$1)
$$

CREATE FUNCTION postgis_scripts_build_date () RETURNS text
	LANGUAGE sql
AS $$
SELECT '2016-09-30 20:19:33'::text AS version
$$

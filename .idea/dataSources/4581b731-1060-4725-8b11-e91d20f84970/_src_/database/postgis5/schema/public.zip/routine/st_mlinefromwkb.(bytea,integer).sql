CREATE FUNCTION st_mlinefromwkb (bytea, integer) RETURNS geometry
	LANGUAGE sql
AS $$
	SELECT CASE WHEN public.geometrytype(public.ST_GeomFromWKB($1, $2)) = 'MULTILINESTRING'
	THEN public.ST_GeomFromWKB($1, $2)
	ELSE NULL END
	
$$

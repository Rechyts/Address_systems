CREATE FUNCTION raster_overlap (raster, raster) RETURNS boolean
	LANGUAGE sql
AS $$
select $1::geometry OPERATOR(public.&&) $2::geometry
$$

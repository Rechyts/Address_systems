CREATE FUNCTION st_worldtorastercoordy (rast raster, yw double precision) RETURNS integer
	LANGUAGE sql
AS $$
 SELECT rowy FROM public._ST_worldtorastercoord($1, NULL, $2) 
$$

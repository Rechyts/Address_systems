CREATE FUNCTION overlaps_nd (geometry, gidx) RETURNS boolean
	LANGUAGE sql
AS $$
  SELECT $2 OPERATOR(public.&&&) $1;
$$

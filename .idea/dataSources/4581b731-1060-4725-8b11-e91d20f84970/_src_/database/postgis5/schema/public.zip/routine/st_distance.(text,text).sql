CREATE FUNCTION st_distance (text, text) RETURNS double precision
	LANGUAGE sql
AS $$
 SELECT ST_Distance($1::public.geometry, $2::public.geometry);  
$$

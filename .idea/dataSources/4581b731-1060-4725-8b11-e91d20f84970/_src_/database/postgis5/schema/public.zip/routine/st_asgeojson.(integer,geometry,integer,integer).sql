CREATE FUNCTION st_asgeojson (gj_version integer, geom geometry, maxdecimaldigits integer DEFAULT 15, options integer DEFAULT 0) RETURNS text
	LANGUAGE sql
AS $$
 SELECT public.ST_AsGeoJson($2::public.geometry, $3::int4, $4::int4); 
$$
